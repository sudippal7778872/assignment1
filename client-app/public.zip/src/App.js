import React from 'react'
import { useEffect } from 'react';
import { useState } from 'react'
import Table from './components/Table'


const App = () => {
  const [apiData, setApiData] = useState([]);
  const submit = () => {
    fetch("https://api.sampleapis.com/countries/countries")
    .then((res)=>{
      console.log(res);
      res.json().then((data)=>{
        console.log(data)
        setApiData(data)
      })
    })
    .catch((err)=>{

    })
  }
  useEffect(()=>{

  })
  return (
    <div>
        <button onClick={submit}> Get Data</button>
        <div>
        <table>
                <thead>
                <tr>
                    <th>Country Name</th>
                    <th>Flag </th>
                    <th>Currency</th>
                    <th>Population</th>
                </tr>
                </thead>
        {
          console.log("this is",apiData)}
          {apiData.map((value)=>{
            
            <Table
              key={value.id}
              Country={value.name}
              Flag={value.media.Flag}
              Currency={value.Currency}
              Population={value.Population}
            />
          })
        }
        </table>
        
        </div>
    </div>
  )
}

export default App